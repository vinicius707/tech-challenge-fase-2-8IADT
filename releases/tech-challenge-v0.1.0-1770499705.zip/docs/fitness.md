# Fitness — métricas e penalidades

Este documento descreve a função de fitness inicial usada para avaliar soluções VRP.

1) Fórmula básica

Fitness (quanto menor, melhor) é calculado como:

```
fitness = w_distance * total_distance + w_capacity * capacity_penalty + w_priority * priority_penalty
```

- total_distance: soma das distâncias de todas as rotas (em km), calculada via Haversine.  
- capacity_penalty: penalidade quando a soma dos volumes em uma rota excede a capacidade do veículo (ex.: soma(max(0, load - capacity)) ).  
- priority_penalty: penalidade se entregas de alta prioridade não forem atendidas ou forem demasiadamente atrasadas (definição a refinar).

2) Pesos configuráveis

Os pesos são lidos do arquivo de configuração YAML (`experiments/configs/*.yaml`) e permitem balancear distância vs. restrições.

3) Notas de implementação

- Usamos Haversine para calcular distância entre coordenadas (lat/lon).  
- Penalidades são multiplicadas por fatores configuráveis; inicialmente são placeholders mas implementarão fórmulas lineares ou escalonadas.

5) Fórmulas de penalidade (implementação atual)

- capacity_penalty = sum_over_routes(max(0, load_route - vehicle_capacity))
- priority_penalty = sum_over_routes(sum(index_of_stop for each high-priority stop))

Exemplo de configuração YAML:

```yaml
fitness_weights:
  distance: 0.6
  capacity_penalty: 1.0
  priority_penalty: 2.0
vehicle:
  capacity: 100.0
```

6) Testes

Testes unitários em `tests/ga/test_fitness.py` validam Haversine, total_distance_for_route e fitness quando apenas distância é considerada.

## Para iniciantes

- O que é: fitness é um número que resume a qualidade de uma solução; menor = melhor.  
- Como testar rápido: rode `PYTHONPATH=. pytest -q tests/ga/test_fitness.py` ou use o runner de exemplo e verifique `history.csv`.

## Para desenvolvedores

- Use `fitness_for_chromosome(decoded_routes, weights, depot)` em pipelines. `decoded_routes` é lista de rotas, cada rota uma lista de dicts com chaves `id, lat, lon, priority, volume`.  
- Exemplo:

```python
from src.ga.representation import parse_instance_csv, build_points_lookup, decode_chromosome
from src.ga.fitness import fitness_for_chromosome

points = parse_instance_csv("data/instances/hospital_points.csv")
lookup = build_points_lookup(points)
chrom = [[1,2,3],[4,5]]
decoded = decode_chromosome(chrom, lookup)
weights = {"distance":1.0, "capacity_penalty":1.0, "priority_penalty":2.0, "vehicle_capacity":100.0}
f = fitness_for_chromosome(decoded, weights)
print("fitness:", f)
```

